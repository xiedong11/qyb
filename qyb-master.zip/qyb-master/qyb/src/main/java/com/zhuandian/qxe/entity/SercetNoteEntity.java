package com.zhuandian.qxe.entity;

/**
 * Created by 谢栋 on 2016/11/3.
 */
public class SercetNoteEntity {

    private int id;
    private String time;
    private String content;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String gettime() {
        return time;
    }

    public void settime(String time) {
        this.time = time;
    }
}
