package com.zhuandian.qxe.utils;

/**
 * 定义存放全局变量的类
 * Created by 谢栋 on 2017/1/5.
 */
public class GlobalVariable {

    public static String JWC_URL="http://www.qfnu.edu.cn/";
    public static boolean SHARE_LIST_FLAG =false;   //设置全部动态跟当前用户动态区分的标志位，false代表全部
}
