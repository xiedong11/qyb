package com.zhuandian.qxe.wxapi;

import com.umeng.weixin.callback.WXCallbackActivity;

/**
 * desc :微信分享回调
 * author：xiedong
 * data：2018/1/31
 */

public class WXEntryActivity extends WXCallbackActivity {
}
