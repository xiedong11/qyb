package com.zhuandian.qxe.ExtralModule.gradeQuery;

/**
 * 用于配置WebView的接口
 * Created by 谢栋 on 2017/5/14.
 */

public interface WebViewSetting {
    void webViewSetting();
}
