package com.zhuandian.qxe.apshare;

import com.umeng.socialize.media.ShareCallbackActivity;

/**
 * desc :支付宝分享回调
 * author：xiedong
 * data：2018/1/31
 */

public class ShareEntryActivity extends ShareCallbackActivity {
}
