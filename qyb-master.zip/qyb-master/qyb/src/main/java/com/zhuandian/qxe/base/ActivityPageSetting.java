package com.zhuandian.qxe.base;

/**
 * Created by 谢栋 on 2017/5/13.
 */

public interface ActivityPageSetting {
    int getLayoutId();
    void setupView();
    void setModle();
}
