//package com.zhuandian.qxe.ExtralModule.heartshare;
//
//import android.app.Activity;
//
///**
// * Created by 谢栋 on 2016/12/19.
// */
//public class ShareActivity extends Activity{
//}
